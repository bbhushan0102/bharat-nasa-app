const pgp = require("pg-promise")({ promiseLib: Promise });

const config = {
  port: 5432,
  host: "localhost",
  database: "gaming",
  user: "bharat",
  password: "123"
};

const db = pgp(config);
module.exports = db;

// const initOptions = { promiseLib: Promise };
// const pgp = require("pg-promise")(initOptions);
// const dbConfig = require("./config");
// const db = pgp(dbConfig);

// // USE THIS INSTANCE OF DB IN CHALLENGE 2
// module.exports = db;
