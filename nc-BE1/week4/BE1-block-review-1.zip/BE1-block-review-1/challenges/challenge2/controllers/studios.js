const db = require("../db");

const getStudios = (req, res) => {
  db.many("SELECT * FROM studios;").then(studios => {
    res.status(200).send({ studios });
  });
};

const addStudio = (req, res) => {
  const newStudio = req.body;
  db.one(
    "INSERT INTO consoles (studio_name, year_established) VALUES ($<studio_name>, $< year_established>) RETURNING *;",
    newStudio
  ).then(newStudio => {
    res.status(201).send({ newStudio });
  });
};

module.exports = {
  getStudios,
  addStudio
};
