const db = require("../db");

const getGenres = (req, res) => {
  db.many("SELECT * FROM genres;").then(genres => {
    res.status(200).send({ genres });
  });
};

const getGenresById = (req, res) => {
  const { genre_id } = req.params;
  db.one("SELECT * FROM genres WHERE id = $<genre_id>", { genre_id })
    .then(genre => {
      res.status(200).send({ genre });
    })
    .catch(err => {
      console.log(err, "ERROR <<<<<");
      // res.status(200).send({ msg: "invalid input" });
    });
};

const getGameByGenre = (req, res) => {
  const { genre_id } = req.params;

  db.many(
    "SELECT * FROM games JOIN genres ON games.id = genres.id WHERE games.id = $<genre_id>",
    { genre_id }
  ).then(games => {
    res.status(200).send({ games });
  });
};

module.exports = { getGenres, getGenresById, getGameByGenre };
