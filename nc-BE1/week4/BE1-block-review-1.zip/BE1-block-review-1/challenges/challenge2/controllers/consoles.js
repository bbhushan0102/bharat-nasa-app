const db = require("../db");

const getConsoles = (req, res) => {
  db.many("SELECT * FROM consoles;").then(consoles => {
    res.status(200).send({ consoles });
  });
};

const addConsoles = (req, res) => {
  const newConsole = req.body;
  db.one(
    "INSERT INTO consoles (console_name, console_year) VALUES ($<console_name>, $<console_year>) RETURNING *;",
    newConsole
  ).then(newConsole => {
    res.status(200).send({ newConsole });
  });
};

const getConsolesById = (req, res) => {
  const { console_id } = req.params;
  console.log(req.params);
  db.one("SELECT * FROM consoles WHERE id = $<console_id>", {
    console_id
  })
    .then(consoles => {
      res.status(200).send({ consoles });
    })
    .catch(err => {
      console.log(err, "ERROR <<<<<");
      res.status(400).send({ msg: "invalid input" });
    });
};

const getGamesByConsoleId = (req, res) => {
  db.many(
    "SELECT * FROM games JOIN consoles ON games.id = consoles.id WHERE id=$<console_id>",
    req.params
  )
    .then(games => {
      res.status(200).send({ games });
    })
    .catch(console.log);
};

module.exports = {
  getConsoles,
  addConsoles,
  getConsolesById,
  getGamesByConsoleId
};
