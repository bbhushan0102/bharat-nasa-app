const apiRouter = require("express").Router();
const genresRouter = require("./genres");
const consolesRouter = require("./consoles");
const studiosRouter = require('./studios')
apiRouter.use("/genres", genresRouter);
apiRouter.use("/consoles", consolesRouter);
apiRouter.use('/studios', studiosRouter)

module.exports = apiRouter;
