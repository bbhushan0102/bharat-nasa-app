const studiosRouter = require("express").Router();
const { getStudios, addStudio } = require("../controllers/studios");

studiosRouter
  .route("/")
  .get(getStudios)
  .post(addStudio);

module.exports = studiosRouter;
