const consolesRouter = require("express").Router();
const {
  getConsoles,
  addConsoles,
  getConsolesById,
  getGamesByConsoleId
} = require("../controllers/consoles");

consolesRouter.route("/").get(getConsoles).post(addConsoles);
consolesRouter.route("/:console_id").get(getConsolesById);
consolesRouter.route("/:console_id/games").get(getGamesByConsoleId);

module.exports = consolesRouter;
//:console_id/games
