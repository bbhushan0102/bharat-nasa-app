const genresRouter = require("express").Router();
const {
  getGenres,
  getGenresById,
  getGameByGenre
} = require("../controllers/genres");


genresRouter.route('/').get(getGenres);
genresRouter.route("/:genre_id").get(getGenresById);
genresRouter.route("/:genre_id/games").get(getGameByGenre);

module.exports = genresRouter;

