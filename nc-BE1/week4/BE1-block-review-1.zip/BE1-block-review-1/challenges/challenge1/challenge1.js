const { preparePizza, cookPizza, boxPizza } = require("./utils/pizzas");

function makePizzas(order, cb) {
  if (order.length === 0) cb(null, order);
  const pizzaBox = [];
  let count = 0;
  order.forEach((pizzaOrder, index) => {
    preparePizza(pizzaOrder, (err, rawpizza) => {
      cookPizza(rawpizza, (err, cookedPizza) => {
        boxPizza(cookedPizza, (err, boxedPizza) => {
          pizzaBox[index] = boxedPizza;
          count++;
          if (count === order.length) {
            cb(null, pizzaBox);
            // console.log(pizaBox)
          }
        });
      });
    });
  });
}

module.exports = makePizzas;
