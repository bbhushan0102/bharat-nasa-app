const { expect } = require('chai');
const deeplyEquals = require('../challenges/challenge4');

describe('deeplyEquals', () => {
    it ('returns true if primitive values are same', () => {
        expect(deeplyEquals('a','a')).to.equal(true);
    })
    it ('returns false if primitive values are not same', () => {
        expect(deeplyEquals('a','b')).to.equal(false);
    })
    it ('returns true if both arrays have same value', () => {
        const a = [1, 2, 3];
        const b = [1, 2, 3];
        expect(deeplyEquals(a,b)).to.equal(true);
    })
    it ('returns true if values in arrays or in object are same', () => {
        expect(deeplyEquals([1, 2, { a: 'hello' }], [1, 2, { a: 'hello' }])).to.equal(true);
    })
    it ('returns false if values in arrays or in object are not same', () => {
        expect(deeplyEquals([1, 2, { a: 'hello' }], [1, 2, { a: 'bye' }])).to.equal(false);
    })
   
});
