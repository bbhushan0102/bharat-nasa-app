const { expect } = require('chai');
const { VendingMachine, Stock } = require('../challenges/challenge3');

describe('Stock', () => {
    it('tests a new instance of stock', () => {
        const instance = new Stock()
    expect(instance).to.be.an.instanceOf(Stock);
    });
    it('test properties of a stock class i.e name, price and quantity', () => {
        const marsBars = new Stock('marsBar', '50p', 6);
    expect(marsBars.name).to.equal('marsBar');
    expect(marsBars.price).to.equal('50p');
    expect(marsBars.quantity).to.equal(6);
    });
});
describe('VendingMachine', () => {
    it('tests a new instance of Vending Machine class', () => {
        const vm = new VendingMachine()
    expect(vm).to.be.an.instanceOf(VendingMachine);
    });
    it('test dispenser property of a vending Machine which return empty array ', () => {
        const testMachine = new VendingMachine();
    expect(testMachine.dispenser).to.eql([]);
    });
    it('test credit property of a vendingMachine which return zero (amount of pence) ', () => {
        const testMachine = new VendingMachine();
    expect(testMachine.credit).to.equal(0);
    });
    it('test stock property of a vendingMachine class, it return three keys of an object ', () => {
        const testMachine = new VendingMachine();
    expect(testMachine.stock).to.eql({A : [{},{},{}], B : [{},{},{}], C : [{},{},{}]});
    });
    it('add stock method add new stock instance to the vending machine ', () => {
        const marsBars = new Stock('marsBar', '50p', 6);
        const testMachine = new VendingMachine();
        testMachine.addStock(marsBars, 'A1');
    expect(testMachine.stock).to.eql({A: [{ name: 'marsBar', price: '50p', quantity: 6 }, {}, {} ],
    B: [ {}, {}, {} ],
    C: [ {}, {}, {} ] });
    });
    it('test addCredit mthod of a vendingMachine class', () => {
        const testMachine = new VendingMachine();
        testMachine.addCredit(50);
    expect(testMachine.credit).to.equal(50);
    });
    it('test addCredit method add values', () => {
        const testMachine = new VendingMachine();
        testMachine.addCredit(50);
        testMachine.addCredit(10);
    expect(testMachine.credit).to.equal(60);
    });
    it('return insufficent credit if credit is less then 50p', () => {
        const marsBars = new Stock('marsBar', '50p', 6);
        const testMachine = new VendingMachine();
        testMachine.addStock(marsBars, 'A2');
        testMachine.addCredit(30);
    expect(testMachine.purchaseItem('A2')).to.equal('Insufficent credit!');
    });
    it('add an item to dispenser anddecrease quantity if has sufficent credit', () => {
        const marsBars = new Stock('marsBar', '50p', 6);
        const testMachine = new VendingMachine();
        testMachine.addStock(marsBars, 'A1');
        testMachine.addCredit(60);
        testMachine.purchaseItem('A1');
        testMachine.stock;
    expect(testMachine.credit).to.equal(10);
    expect(testMachine.dispenser).to.eql(['marsBar']);
    expect(testMachine.stock).to.eql({A: [{ name: 'marsBar', price: '50p', quantity: 5 }, {}, {} ],
    B: [ {}, {}, {} ],
    C: [ {}, {}, {} ] });
    });
});

