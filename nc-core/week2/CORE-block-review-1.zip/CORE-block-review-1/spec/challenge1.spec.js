const { expect } = require('chai');
const createTally = require('../challenges/challenge1');
const NCFruitBowl = require('../data/challenge1-data.js')

describe('createTally',() => {
    it('return object when pass an array',() => {
        expect(createTally([])).to.eql({})
    })
    it('return tally desert if array has one element',() => {
        expect(createTally(['cake'])).to.eql({cake: 1})
    })
    it('return tally desert if array has more then one elements',() => {
        expect(createTally(['cake', 'biscuit'])).to.eql({cake: 1, biscuit: 1})
    })
    it('return tally desert if array has same elements',() => {
        expect(createTally(['dog', 'dog', 'dog'])).to.eql({dog : 3})
    })
    it('return tally dessert for imported file',() => {
        expect(createTally(NCFruitBowl)).to.eql({ apple: 276, pear: 223, banana: 263, orange: 238, 'lonesome plum': 1})
    })
});