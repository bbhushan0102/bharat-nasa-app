function createTally(arr) {
    const result = arr.reduce ((tally, dessert) => {
        if(tally[dessert] === undefined) {
            tally[dessert] = 1;
        } else {
            tally[dessert]++;
        }
        return tally;
    },{})
    return result;
};

module.exports = createTally;
