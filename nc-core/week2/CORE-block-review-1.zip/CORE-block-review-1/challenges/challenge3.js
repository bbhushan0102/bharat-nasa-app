class Stock {
    constructor (name, price, quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;

    }
}

class VendingMachine {
    constructor () {
        this.dispenser = [];
        this.credit = 0;
        this.stock = {A : [{},{},{}],B : [{},{},{}],C : [{},{},{}]};
    }

    addStock (marsBars, A) {
        if (this.stock[A]=== undefined) {
            this.stock.A[0]= marsBars
        }
    }
    addCredit (value) {
        this.credit = this.credit + value;
    }
    purchaseItem(A) {
        if (this.credit >= 50) {
            this.dispenser.push(this.stock.A[0].name);
            this.credit = this.credit - 50;
            this.stock.A[0].quantity --
        }
        else {
            return ('Insufficent credit!')
        }
        
    }

}

module.exports = { VendingMachine, Stock };
