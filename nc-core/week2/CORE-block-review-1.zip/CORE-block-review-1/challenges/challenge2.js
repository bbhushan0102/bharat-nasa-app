function invert(func) {
    return function (...arg) {
        return !func(...arg)      
    }

}
module.exports = invert;
