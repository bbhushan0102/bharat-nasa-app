function deeplyEquals(a,b) {
    if(a === b) return true;
    else if (typeof a === 'object' && typeof b === 'object') {
        if(Array.isArray(a) === Array.isArray(b)) {
            for (let key in a) {
                if (key in b) {  
                    if (! deeplyEquals(a[key], b[key])) {
                    return false;
                    } 
                }   else {
                    return false;
                }
            
            }
            return true;
        }
    }
    return false;
}
module.exports = deeplyEquals;