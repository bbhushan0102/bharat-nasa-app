# CORE BLOCK REVIEW

For this block review, you have several specifications which need to be completed. You are expected to use full TDD in order to demonstrate your understanding of the questions and of good TDD practices. Good luck!

### Challenge 1

Using the appropriate array method, write a function that creates a tally object for arrays. E.g

```js
createTally(['cake', 'biscuit', 'biscuit']); // returns {cake: 1, biscuit: 2}
createTally(['dog', 'dog', 'dog']); // returns {dog: 3}
```

Your final test should be using the NCFruitBowl from the challenge1-data file. _DO NOT COPY AND PASTE THIS INTO YOUR SPEC FILE - it's huge!_ Be sure to export it properly. It should return the following object:

```js
{
  apple: 276,
  pear: 223,
  banana: 263,
  orange: 238,
  'lonesome plum': 1
}
```

### Challenge 2

Write a higher-order function called `invert`.

It should do the following:

* It should return a new function.
* It should take a function as its only argument.
* The inner function should take any number of arguments and inverts a call to the passed function

We have provided the tests to help you build it to our specifications. Build up your functionality by following the tests in order. DO NOT attempt to design a function that will pass all our tests in one go.
    });    });
### Challenge 3

**SECTION A**

Write a `Stock` class that will return stock instances.

An instance of the `Stock` class must have the following properties:

It must have name, price and quantity properties:

```js
const marsBars = new Stock('marsBar', '50p', 6);

marsBars.name; // 'marsBar'

marsBars.price; // '50p'

marsBars.quantity; // 6
```

**SECTION B**

Write a `VendingMachine` class that will return vending machine instances.

It must have a `dispenser` property, which is an empty array

```js
const testMachine = new VendingMachine();
testMachine.dispenser; // []
```

It must have a `credit` property, which will be a **number** representing amount of pence, starting at `0`.

```js
const testMachine = new VendingMachine();
testMachine.credit; // 0;
```

It must have a stock property, which will be an object with three keys:
It represents the positions in the machine: e.g. A1, A2, A3, ...etc

```js
const testMachine = new VendingMachine();
testMachine.stock;
/** {
A : [{},{},{}],
B : [{},{},{}],
C : [{},{},{}]
};
**/
```

It must have an `addStock` method which will add new stock instances to the vending machine at the correct position.

```js
const marsBars = new Stock('marsBar', '50p', 6);
const testMachine = new VendingMachine();
testMachine.addStock(marsBars, 'A1');
testMachine.stock;
/**
{ A: [{ name: 'marsBar', price: '50p', quantity: 6 }, {}, {} ],
  B: [ {}, {}, {} ],
  C: [ {}, {}, {} ] }
 **/
```

It must have an `addCredit` method which will update the machine credit.

```js
const testMachine = new VendingMachine();
testMachine.credit; // 0
testMachine.addCredit(50);
testMachine.credit; // 50
testMachine.addCredit(10);
testMachine.credit; // 60;
```

It must have a `purchaseItem` method which will **decrease** the quantity of the stock if there is sufficient credit and it will add an item to the dispenser.

```js
const marsBars = new Stock('marsBar', '50p', 6);
const testMachine = new VendingMachine();
testMachine.addStock(marsBars, 'A2');
testMachine.addCredit(30);
testMachine.purchaseItem('A2'); // returns 'Insufficent credit!'
```

```js
const marsBars = new Stock('marsBar', '50p', 6);
const testMachine = new VendingMachine();
testMachine.addStock(marsBars, 'A1');
testMachine.addCredit(60);
testMachine.purchaseItem('A1');
testMachine.stock;
/**
{ A: [{ name: 'marsBar', price: '50p', quantity: 5 }, {}, {} ],
  B: [ {}, {}, {} ],
  C: [ {}, {}, {} ] }
 **/
testMachine.credit; // 10
testMachine.dispenser; // ['marsBar']
```

### Challenge 4

Implement a function called `deeplyEquals`. This function will check if two passed variables contain the same values. If passed Arrays or Objects the function will check the contents for equality.
You must use recursion in your implementation of this method.
Be sure to build up your tests carefully and take care in building up your logic step by step.

```js
deeplyEquals('a', 'a'); // true
deeplyEquals('a', 'b'); // false
deeplyEquals([1, 2, { a: 'hello' }], [1, 2, { a: 'hello' }]); // true
deeplyEquals([1, 2, { a: 'hello' }], [1, 2, { a: 'bye' }]); // false
```
